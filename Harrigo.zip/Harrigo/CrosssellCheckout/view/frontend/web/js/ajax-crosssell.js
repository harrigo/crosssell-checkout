require(["jquery", "domReady!"], function($){
	function waitForElement(elementPath, callBack){
	  window.setTimeout(function(){
		if($(elementPath).length){
		  callBack(elementPath, $(elementPath));
		}else{
		  waitForElement(elementPath, callBack);
		}
	  },500)
	}
	
   $.get('/harrigocrosssell/index/crosssell?cart=yes',function(response){
	   waitForElement("#crosssellblock",function(){
		   if (response=="<html><head></head><body></body></html>") {
			   alert("no products");
		   }
			$("#crosssellblock").html(response);
		});
	   })
});
